import React from 'react'
import './divflex.css'
export default function Divflex () {
	return (
		<div className='divflex_divflex'>
		</div>
	)
}