import React from 'react'
import {Link} from 'react-router-dom'
export default function HomePage () {
    return (
	<div>
		<Link to='/Frame'><div>Frame</div></Link>
		<Link to='/divmxauto'><div>divmxauto</div></Link>
		<Link to='/divmt8'><div>divmt8</div></Link>
		<Link to='/divflex'><div>divflex</div></Link>
		<Link to='/iconamoonprofilecirclethin'><div>iconamoonprofilecirclethin</div></Link>
		<Link to='/iconamoonprofilecirclethin_1'><div>iconamoonprofilecirclethin_1</div></Link>
		<Link to='/Frame_1'><div>Frame_1</div></Link>
		<Link to='/divhidden'><div>divhidden</div></Link>
		<Link to='/Frame_2'><div>Frame_2</div></Link>
		<Link to='/divmxauto_1'><div>divmxauto_1</div></Link>
		<Link to='/divcontainer'><div>divcontainer</div></Link>
		<Link to='/divcontainer_1'><div>divcontainer_1</div></Link>
		<Link to='/divcard'><div>divcard</div></Link>
		<Link to='/divcard_1'><div>divcard_1</div></Link>
		<Link to='/divcard_2'><div>divcard_2</div></Link>
		<Link to='/Frame_3'><div>Frame_3</div></Link>
		<Link to='/divcontainer_2'><div>divcontainer_2</div></Link>
		<Link to='/divcontainer_3'><div>divcontainer_3</div></Link>
		<Link to='/divwhitebackground'><div>divwhitebackground</div></Link>
		<Link to='/divFeatures'><div>divFeatures</div></Link>
		<Link to='/divglobalpadding'><div>divglobalpadding</div></Link>
		<Link to='/divServices'><div>divServices</div></Link>
		<Link to='/divFAQ'><div>divFAQ</div></Link>
		<Link to='/divglobalpadding_1'><div>divglobalpadding_1</div></Link>
		<Link to='/divfooterborder'><div>divfooterborder</div></Link>
		<Link to='/divcard_3'><div>divcard_3</div></Link>
		<Link to='/divcard_4'><div>divcard_4</div></Link>
		<Link to='/divcard_5'><div>divcard_5</div></Link>
		<Link to='/Frame_4'><div>Frame_4</div></Link>
		<Link to='/arrowright'><div>arrowright</div></Link>
		<Link to='/product_card'><div>product_card</div></Link>
	</div>
	)
}