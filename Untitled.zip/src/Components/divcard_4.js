import React from 'react'
import './divcard_4.css'
import ImgAsset from '../public'
export default function Divcard_4 () {
	return (
		<div className='divcard_4_divcard'>
			<img className='_64a6cdff000962bbfb4a9cd0_mainp500jpg' src = {ImgAsset.divcard_1__64a6cdff000962bbfb4a9cd0_mainp500jpg} />
			<img className='Star1' src = {ImgAsset.divcard_4_Star1} />
		</div>
	)
}