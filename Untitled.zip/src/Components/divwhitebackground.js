import React from 'react'
import './divwhitebackground.css'
export default function Divwhitebackground () {
	return (
		<div className='divwhitebackground_divwhitebackground'>
			<div className='divblackframe'>
			</div>
			<div className='divblackframe_1'>
			</div>
		</div>
	)
}