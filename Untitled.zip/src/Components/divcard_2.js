import React from 'react'
import './divcard_2.css'
import ImgAsset from '../public'
export default function Divcard_2 () {
	return (
		<div className='divcard_2_divcard'>
			<img className='_64a6cdff000962bbfb4a9cd5_sc3p500jpg' src = {ImgAsset.divcard_2__64a6cdff000962bbfb4a9cd5_sc3p500jpg} />
			<img className='Star1' src = {ImgAsset.divcard_2_Star1} />
		</div>
	)
}