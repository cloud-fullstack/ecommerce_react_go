import React from 'react'
import './divmxauto_1.css'
export default function Divmxauto_1 () {
	return (
		<div className='divmxauto_1_divmxauto'>
		</div>
	)
}