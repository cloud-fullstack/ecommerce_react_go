import React from 'react'
import './iconamoonprofilecirclethin_1.css'
export default function Iconamoonprofilecirclethin_1 () {
	return (
		<div className='iconamoonprofilecirclethin_1_iconamoonprofilecirclethin'>
		</div>
	)
}