import React from 'react'
import './product_card.css'
export default function Product_card (props) {
	return (
		<div className={`product_card_product_card ${props.className}`}>
		</div>
	)
}