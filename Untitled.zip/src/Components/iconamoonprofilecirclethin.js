import React from 'react'
import './iconamoonprofilecirclethin.css'
export default function Iconamoonprofilecirclethin () {
	return (
		<div className='iconamoonprofilecirclethin_iconamoonprofilecirclethin'>
		</div>
	)
}