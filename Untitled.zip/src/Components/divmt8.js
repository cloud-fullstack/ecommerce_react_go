import React from 'react'
import './divmt8.css'
export default function Divmt8 () {
	return (
		<div className='divmt8_divmt8'>
			<span className='Heading3Subscribetoournewsletter'>Subscribe to our newsletter</span>
			<div className='pmt4'>
				<span className='Thelatestnewsarticlesandresourcessenttoyourinboxweekly'>The latest news, articles, and resources, sent to your<br/>inbox weekly.</span>
			</div>
			<div className='Form'>
			</div>
		</div>
	)
}