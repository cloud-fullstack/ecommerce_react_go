import React from 'react'
import './divglobalpadding_1.css'
import ImgAsset from '../public'
export default function Divglobalpadding_1 () {
	return (
		<div className='divglobalpadding_1_divglobalpadding'>
			<div className='divflexframe'>
				<div className='divsubscribecontent'>
					<div className='divleftalign'>
						<div className='divheadingmedium'>
							<span className='Everything'>Everything</span>
							<span className='need'> need</span>
						</div>
					</div>
					<div className='divsubscribecontainer'>
						<div className='FormEmailForm'>
							<span className='LabelEmailAddress'>Email Address</span>
						</div>
					</div>
				</div>
				<div className='divsubscribeimage'>
					<img className='_64a6cdff000962bbfb4a9cc6_newsletterp500jpg' src = {ImgAsset.divglobalpadding_1__64a6cdff000962bbfb4a9cc6_newsletterp500jpg} />
				</div>
			</div>
		</div>
	)
}