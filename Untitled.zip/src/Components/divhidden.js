import React from 'react'
import './divhidden.css'
export default function Divhidden () {
	return (
		<div className='divhidden_divhidden'>
		</div>
	)
}