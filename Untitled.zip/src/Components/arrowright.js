import React from 'react'
import './arrowright.css'
export default function Arrowright (props) {
	return (
		<div className={`arrowright_arrowright ${props.className}`}>
		</div>
	)
}